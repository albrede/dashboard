<?php
// app/Filament/Responses/SupplierLoginResponse.php

namespace App\Http\Responses;

use Filament\Http\Responses\Auth\Contracts\LoginResponse;
use Illuminate\Http\RedirectResponse;

class SupplierLoginResponse implements LoginResponse
{
    public function toResponse($request): RedirectResponse
    {
        return redirect()->intended('/supplier/dashboard');
    }
}
