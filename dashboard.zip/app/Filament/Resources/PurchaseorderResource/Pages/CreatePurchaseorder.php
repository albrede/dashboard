<?php

namespace App\Filament\Resources\PurchaseorderResource\Pages;

use App\Filament\Resources\PurchaseorderResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePurchaseorder extends CreateRecord
{
    protected static string $resource = PurchaseorderResource::class;
}
