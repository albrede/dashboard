<?php

namespace App\Auth;

use Illuminate\Contracts\Auth\Authenticatable;
use Illuminate\Contracts\Auth\UserProvider;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Contracts\Hashing\Hasher;

class NestJsUserProvider implements UserProvider
{
    protected $hasher;
    protected $model;

    public function __construct(Hasher $hasher = null, $model = null)
    {
        $this->hasher = $hasher;
        $this->model = $model;
    }

    public function retrieveById($identifier)
    {
        return null;
    }

    public function retrieveByToken($identifier, $token)
    {
        return null;
    }

    public function updateRememberToken(Authenticatable $user, $token)
    {
        // Not used
    }

    public function retrieveByCredentials(array $credentials)
    {
        Log::info('Attempting authentication with NestJS backend', [
            'email' => $credentials['email']
        ]);

        try {
            // First try pharmacy user login
            $userResponse = Http::timeout(10)->post(
                config('services.nestjs.url') . '/auth/user/signin',
                [
                    'email' => $credentials['email'],
                    'password' => $credentials['password'],
                ]
            );

            Log::info('User login response', [
                'status' => $userResponse->status(),
                'body' => $userResponse->body()
            ]);

            if ($userResponse->successful()) {
                $token = $userResponse->json('access_token');
                $payload = $this->decodeJwt($token);

                Log::info('User authenticated successfully', $payload);

                session([
                    'nestjs_token' => $token,
                    'token_expiry' => $payload['exp'],
                    'user_payload' => $payload
                ]);

                return new NestJsUser($payload);
            }
        } catch (\Exception $e) {
            Log::error('User login error', [
                'message' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
        }

        try {
            // If user login failed, try supplier login
            $supplierResponse = Http::timeout(10)->post(
                config('services.nestjs.url') . '/auth/supplier/signin',
                [
                    'email' => $credentials['email'],
                    'password' => $credentials['password'],
                ]
            );

            Log::info('Supplier login response', [
                'status' => $supplierResponse->status(),
                'body' => $supplierResponse->body()
            ]);

            if ($supplierResponse->successful()) {
                $token = $supplierResponse->json('access_token');
                $payload = $this->decodeJwt($token);

                Log::info('Supplier authenticated successfully', $payload);

                session([
                    'nestjs_token' => $token,
                    'token_expiry' => $payload['exp'],
                    'user_payload' => $payload
                ]);

                return new NestJsUser($payload);
            }
        } catch (\Exception $e) {
            Log::error('Supplier login error', [
                'message' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
        }

        Log::warning('Authentication failed for email: ' . $credentials['email']);
        return null;
    }

    public function validateCredentials(Authenticatable $user, array $credentials)
    {
        return true;
    }

    public function rehashPasswordIfRequired(
        Authenticatable $user,
        array $credentials,
        bool $force = false
    ): bool {
        return false;
    }

    private function decodeJwt(string $token): array
    {
        $parts = explode('.', $token);
        if (count($parts) !== 3) {
            throw new \Exception('Invalid JWT format');
        }

        return json_decode(base64_decode(str_replace(['-', '_'], ['+', '/'], $parts[1])), true);
    }
}
