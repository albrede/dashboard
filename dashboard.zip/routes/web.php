<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;
use App\Filament\Pages\Auth\UserLogin;
use App\Filament\Pages\Auth\SupplierLogin;
use Filament\Facades\Filament;

Route::middleware('web')->group(function () {
    Route::get('/', function () {
        return view('welcome');
    });

    // FIX: Use the correct guard ('filament') for authentication
    Route::get('/test-auth', function () {
        // Explicitly use the 'filament' guard
        if (Auth::guard('filament')->check()) {
            return response()->json([
                'user' => Auth::guard('filament')->user(),
                'token' => session('nestjs_token'),
                'payload' => session('user_payload')
            ]);
        }
        return response()->json(['error' => 'Not authenticated'], 401);
    });

    // ADD: Test connection to NestJS backend
    Route::get('/test-connection', function () {
        try {
            $response = Http::get(config('services.nestjs.url') . '/health');
            return response()->json([
                'status' => 'connected',
                'response' => $response->json()
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => $e->getMessage(),
                'url' => config('services.nestjs.url')
            ], 500);
        }
    });


    Route::get('/user/signin', UserLogin::class)->name('filament.user.login');
    Route::get('/supplier/signin', SupplierLogin::class)->name('filament.supplier.login');
    Route::redirect('/login', '/user/signin')->name('login');
    Route::redirect('/supplier/login', '/supplier/signin')->name('supplierlogin');

    Route::get('/test-token', function () {
        return response()->json([
            'token' => session('nestjs_token'),
            'user' => auth('filament')->user(),
        ]);
    });
    Route::get('/debug-session', function () {
        return [
            'user' => auth()->guard('supplier')->user(),
            'token' => session('nestjs_token'),
            'session' => session()->all(),
        ];
    });
    Route::get('/debug-panel', function () {
        return filament()->getCurrentPanel()?->getId();
    });
    Route::get('/check-filament', function () {
        return [
            'is_logged_in' => Filament::auth()?->check(),
            'user' => Filament::auth()?->user(),
            // 'guard' => Filament::auth()?->getDefaultDriver(), 
            'panel' => Filament::getCurrentPanel()?->getId(),
            'session' => session()->all(),
        ];
    });
});
