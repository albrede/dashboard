<?php

// config/filament.php

return [
    'auth' => [
        'pages' => [
            'login' => \App\Filament\Pages\Auth\UserLogin::class,
        ],
    ],

    'path' => 'dashboard',

    'panels' => [
        \App\Providers\Filament\AdminPanelProvider::class,
        \App\Providers\Filament\SupplierPanelProvider::class,
    ],
];
